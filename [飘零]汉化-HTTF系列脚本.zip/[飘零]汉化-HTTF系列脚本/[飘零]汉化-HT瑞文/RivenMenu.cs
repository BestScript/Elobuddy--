﻿using System.Reflection;
using EloBuddy.SDK;
using EloBuddy.SDK.Menu;
using EloBuddy.SDK.Menu.Values;
using System.Drawing;
namespace HTTF_Riven_v2
{
    class RivenMenu
    {
        public static Menu Principal, Combo, Burst, Shield, Items, Laneclear, Jungleclear, Flee, Misc, Draw, Killsteal, AnimationCancle, ComboLogic;

        public static void Load()
        {
            Principal = MainMenu.AddMenu("[飘零]汉化-HTTF瑞文", "Riven");
            Principal.AddLabel("[飘零]温馨提示栏目：Use：使用/用     HTTF瑞文版本：" + Assembly.GetExecutingAssembly().GetName().Version);
			Principal.AddLabel("[飘零]汉化脚本群号：310900959");


            Combo = Principal.AddSubMenu("连招设置", "Combo");
            Combo.AddSeparator(3);
            Combo.AddLabel("• 技能设置");
            Combo.Add("UseQCombo", new CheckBox("Use Q?"));
            Combo.Add("UseWCombo", new CheckBox("Use W?"));
            Combo.Add("UseECombo", new CheckBox("Use E"));
            Combo.Add("UseRCombo", new CheckBox("Use R?"));
            Combo.Add("UseR2Combo", new CheckBox("Use R2?"));
            Combo.Add("BrokenAnimations", new CheckBox("大笑模式",false));
            Combo.Add("moveback", new CheckBox("连招移动到敌人背后？?", false));
            Combo.AddSeparator(3);
            Combo.AddLabel("• 大招设置");
            Combo.Add("UseRType", new ComboBox("Use R when", 1, "目标生命值低于X使用R", "DamageIndicator greater than 100 %", "Always", "On Keypress"));
            Combo.Add("ForceR", new KeyBind("快捷R", false, KeyBind.BindTypes.PressToggle, 'U'));
            Combo.Add("DontR1", new Slider("目标生命值低于使用R", 25, 10, 50));
            Combo.AddSeparator(3);
            Combo.AddLabel("• 二段R设置");
            Combo.Add("UseR2Type", new ComboBox("使用R2", 0, "能击杀", "最大伤害"));
            Combo.AddLabel(" 逃跑");
            Combo.Add("UseQFlee", new CheckBox("Use Q"));
            Combo.Add("UseEFlee", new CheckBox("Use E"));

            Shield = Principal.AddSubMenu("护盾设置", "Shield");
            Shield.AddLabel("• 使用 E");
            foreach (var Enemy in EntityManager.Heroes.Enemies)
            {
                Shield.AddLabel(Enemy.ChampionName);
                Shield.Add("E/" + Enemy.BaseSkinName + "/Q", new CheckBox(Enemy.ChampionName + " (Q)", false));
                Shield.Add("E/" + Enemy.BaseSkinName + "/W", new CheckBox(Enemy.ChampionName + " (W)", false));
                Shield.Add("E/" + Enemy.BaseSkinName + "/E", new CheckBox(Enemy.ChampionName + " (E)", false));
                Shield.Add("E/" + Enemy.BaseSkinName + "/R", new CheckBox(Enemy.ChampionName + " (R)", false));
                Shield.AddSeparator(1);
            }




            Laneclear = Principal.AddSubMenu("清线设置", "Laneclear");
            Laneclear.AddLabel("• 清兵");
            Laneclear.Add("UseQLane", new CheckBox("Use Q"));
            Laneclear.Add("UseWLane", new CheckBox("Use W"));
            Laneclear.Add("UseWLaneMin", new Slider("X个小兵使用W", 3, 0, 10));
            Laneclear.AddLabel("• 请野");
            Laneclear.Add("UseQJG", new CheckBox("Use Q"));
            Laneclear.Add("UseWJG", new CheckBox("Use W"));
            Laneclear.Add("UseEJG", new CheckBox("Use E"));



            Misc = Principal.AddSubMenu("杂项设置", "Misc");
            Misc.Add("Skin", new CheckBox("开启换肤 ?", false));
            Misc.Add("SkinID", new Slider("皮肤名称", 4, 0, 11));
            Misc.Add("Interrupter", new CheckBox("中断插件 ?"));
            Misc.Add("InterrupterW", new CheckBox("中断使用W"));
            Misc.Add("Gapcloser", new CheckBox("防突进 ?"));
            Misc.Add("GapcloserW", new CheckBox("使用W防突进"));
            Misc.Add("AliveQ", new CheckBox("始终保持Q的状态"));
            Misc.AddLabel("• 道具设置");
            Misc.AddLabel("• 贪欲九头蛇");
            Misc.Add("Hydra", new CheckBox("使用九头蛇？"));
            Misc.Add("HydraReset", new CheckBox("用九头蛇重置AA"));
            Misc.AddSeparator(3);
            Misc.AddLabel("• 提亚马特");
            Misc.Add("Tiamat", new CheckBox("使用提亚马特?"));
            Misc.Add("TiamatReset", new CheckBox("使用提亚马特重置AA"));
            Misc.AddSeparator(3);
            Misc.AddLabel("• 水银弯刀");
            Misc.Add("Qss", new CheckBox("使用水银弯刀?"));
            Misc.Add("QssCharm", new CheckBox("魅惑"));
            Misc.Add("QssFear", new CheckBox("恐惧"));
            Misc.Add("QssTaunt", new CheckBox("嘲讽"));
            Misc.Add("QssSuppression", new CheckBox("压制"));
            Misc.Add("QssSnare", new CheckBox("陷阱"));
            Misc.AddSeparator(3);
            Misc.AddLabel("• 幽梦之灵");
            Misc.Add("Youmu", new CheckBox("使用幽梦？"));
            Misc.AddLabel("• 推荐使用250");
            Misc.Add("YoumuRange", new Slider("范围设置", 1, 1, 325));


            Draw = Principal.AddSubMenu("线圈设置", "Drawing");
            Draw.Add("DrawDamage", new CheckBox("Draw Damage"));
            Draw.Add("DrawOFF", new CheckBox("Draw OFF", false));
            Draw.Add("drawjump", new CheckBox("Draw jump(beta)", false));


            AnimationCancle = Principal.AddSubMenu("AnimationCancle", "CanslAnimatio");
            AnimationCancle.Add("4", new CheckBox("Q"));
            AnimationCancle.Add("Spell2", new CheckBox("W"));
            AnimationCancle.Add("Spell3", new CheckBox("E"));
            AnimationCancle.Add("Spell4", new CheckBox("R"));


            ComboLogic = Principal.AddSubMenu("ComboLogic", "ComboLogics");
            ComboLogic.Add("BrokenAnimon", new CheckBox("Use features?"));

            ComboLogic.AddLabel("Q1,Q2,Q3");
            ComboLogic.Add("Q1Hydra", new CheckBox("Q>Hydra"));
            ComboLogic.Add("HydraQ", new CheckBox("Hydra>Q"));
            ComboLogic.Add("QW", new CheckBox("Q>W"));

            

            ComboLogic.AddLabel("W");
            ComboLogic.Add("HydraW", new CheckBox("Hydra>W"));



            ComboLogic.AddLabel("E");
            ComboLogic.Add("EQall", new CheckBox("E>Q"));
            ComboLogic.Add("EW", new CheckBox("E>W"));
            ComboLogic.Add("EH", new CheckBox("E>Hydra or Tiamat"));
            ComboLogic.Add("ER1", new CheckBox("E>R1"));
            ComboLogic.Add("ER2", new CheckBox("E>R2"));


            ComboLogic.AddLabel("R1");
            ComboLogic.Add("R1W", new CheckBox("R1>W"));
            ComboLogic.Add("R1Q", new CheckBox("R1>Q"));
            ComboLogic.Add("R1Hydra", new CheckBox("R1>Hydra or Tiamat"));


            ComboLogic.AddLabel("R2");
            ComboLogic.Add("R2W", new CheckBox("R2>W"));
            ComboLogic.Add("R2Q", new CheckBox("R2>Q"));
            ComboLogic.Add("R2E", new CheckBox("R2>E"));


            ComboLogic.AddLabel("Combo Logic V2 SOON");












        }
        //Cancler
        public static bool AnimationCancelQ
        {
            get { return (AnimationCancle["Spell1"].Cast<CheckBox>().CurrentValue); }
        }
        public static bool AnimationCancelW
        {
            get { return (AnimationCancle["Spell2"].Cast<CheckBox>().CurrentValue); }
        }
        public static bool AnimationCancelE
        {
            get { return (AnimationCancle["Spell3"].Cast<CheckBox>().CurrentValue); }
        }
        public static bool AnimationCancelR
        {
            get { return (AnimationCancle["Spell4"].Cast<CheckBox>().CurrentValue); }
        }



        public static bool CheckBox(Menu m, string s)
        {
            return m[s].Cast<CheckBox>().CurrentValue;
        }

        public static int Slider(Menu m, string s)
        {
            return m[s].Cast<Slider>().CurrentValue;
        }

        public static bool Keybind(Menu m, string s)
        {
            return m[s].Cast<KeyBind>().CurrentValue;

        }



        public static int ComboBox(Menu m, string s)
        {
            return m[s].Cast<ComboBox>().SelectedIndex;
        }
    }
}