﻿using System.Reflection;
using EloBuddy.SDK;
using EloBuddy.SDK.Menu;
using EloBuddy.SDK.Menu.Values;
using System.Drawing;
using System;
using EloBuddy;
using EloBuddy.SDK.Events;
using HTTF_Yasuo.Utils;

namespace HTTF_Yasuo
    {
    class Yasuo
    {
        public static Menu Principal, Combo, Misc, Flee, Clean, Draw, Evadee;

        private static void Main(string[] args)
        {
            Loading.OnLoadingComplete += Loading_OnLoadingComplete;
            Chat.Print("[飘零]汉化-HTTF亚索");
            Game.OnTick += Game_OnTick;
            Game.OnUpdate += OnGameUpdate;

        }       

        private static void Loading_OnLoadingComplete(EventArgs args)
        {
            Principal = MainMenu.AddMenu("[飘零]汉化-HTTF亚索", "Yasuo");
            Principal.AddLabel("[飘零]汉化-HTTF亚索    VER：" + Assembly.GetExecutingAssembly().GetName().Version);
			Principal.AddLabel("飘零QQ：1835525152  脚本群号：310900959");

            //combo+harasse
            Combo = Principal.AddSubMenu("连招设置", "Combo");
            Combo.AddSeparator(3);
            Combo.AddLabel("• 技能设置");
            Combo.Add("UseQCombo", new CheckBox("Use Q"));
            Combo.Add("UseWCombo", new CheckBox("Use W"));
            Combo.Add("UseECombo", new CheckBox("Use E"));
            Combo.Add("UseRCombo", new CheckBox("Use R"));
            Combo.Add("stack.combo", new CheckBox("自动叠 Q?"));
            Combo.Add("combo.leftclickRape", new CheckBox("连招目标使用?"));
            Combo.Add("PredictQ2", new ComboBox("Q2命中", 1, "低", "中", "高"));

            Combo.AddLabel("• 大招设置 ");
            Combo.Add("combo.RTarget", new CheckBox("总是对锁定的目标R"));
            Combo.Add("combo.RKillable", new CheckBox("R抢人头"));
            Combo.Add("combo.MinTargetsR", new Slider("最少X个敌人使用R", 2, 1, 5));

            Combo.AddLabel("• 骚扰设置 ");
            Combo.Add("Auto.Q3", new CheckBox("自动 Q3 ?"));
            Combo.Add("harass.Q", new CheckBox("Use Q"));
            Combo.Add("harass.E", new CheckBox("Use E"));
            Combo.Add("harass.stack", new CheckBox("自动叠Q骚扰?"));
            //clean
            Clean = Principal.AddSubMenu("Clean", "打钱设置");
            Clean.AddSeparator(3);
            Clean.AddLabel("•补兵设置•");
            Clean.Add("LastE", new CheckBox("Use E"));
            Clean.Add("LastQ", new CheckBox("Use Q"));
            Clean.Add("LaseEUT", new CheckBox("在塔下E"));
            Clean.AddLabel("•清兵设置•");
            Clean.Add("WC.Q", new CheckBox("Use Q"));
            Clean.Add("WC.E", new CheckBox("Use E"));
            Clean.AddLabel("•清野设置•");
            Clean.Add("JungQ", new CheckBox("Use Q"));
            Clean.Add("JungE", new CheckBox("Use E"));

            //flee
            Flee = Principal.AddSubMenu("Flee", "逃跑设置");
            Flee.AddSeparator(3);
            Flee.AddLabel("•逃跑•");
            Flee.Add("FleeE", new CheckBox("Use E"));
            Flee.Add("Flee.stack", new CheckBox("逃跑时叠Q"));
            //Draw
            Draw = Principal.AddSubMenu("Draw", "线圈设置");
            Draw.AddSeparator(3);
            Draw.Add("DrawE", new CheckBox(" E "));
            Draw.Add("DrawQ", new CheckBox(" Q "));
            Draw.Add("DrawR", new CheckBox(" R "));
            //Misc
            Misc = Principal.AddSubMenu("Misc", "杂项设置");
            Misc.AddSeparator(3);
            Misc.Add("EGapclos", new CheckBox("E 突进"));
            Misc.Add("Einter", new CheckBox("E 中断"));
            Misc.AddLabel("• 皮肤切换 •");
            Misc.Add("checkSkin", new CheckBox("使用换肤"));
            Misc.Add("Skinid", new Slider("皮肤名称", 0, 0, 10));

            //Evade
            Evadee = Principal.AddSubMenu("Evadee", "闪避设置");
            Evadee.AddSeparator(3);
            Evadee.AddLabel("0.0请等待更新!!");







            Utils.ForDash.Init();


        }
        private static void OnGameUpdate(EventArgs args)
        {
            if (CheckSkin())
            {
                EloBuddy.Player.SetSkinId(SkinId());
            }
        }
        private static int SkinId()
        {
            return Misc["Skinid"].Cast<Slider>().CurrentValue;
        }

        private static bool CheckSkin()
        {
            return Misc["checkSkin"].Cast<CheckBox>().CurrentValue;
        }
    
        private static void Game_OnTick(EventArgs args)
        {
            if (Orbwalker.ActiveModesFlags.HasFlag(Orbwalker.ActiveModes.Flee))
            {
                StateLogic.Flee();
            }
            if (Orbwalker.ActiveModesFlags.HasFlag(Orbwalker.ActiveModes.Harass))
            {
                StateLogic.Harass();
            }
            if (Orbwalker.ActiveModesFlags.HasFlag(Orbwalker.ActiveModes.Combo))
            {
                StateLogic.Combo();
            }
            if (Orbwalker.ActiveModesFlags.HasFlag(Orbwalker.ActiveModes.LastHit))
            {
                StateLogic.LastHit();
            }
            if (Orbwalker.ActiveModesFlags.HasFlag(Orbwalker.ActiveModes.LaneClear))
            {
                StateLogic.WaveClear();
            }
            if (Orbwalker.ActiveModesFlags.HasFlag(Orbwalker.ActiveModes.JungleClear))
            {
                StateLogic.Jungle();
            }
        }
        



            public static bool CheckBox(Menu m, string s)
            {
                return m[s].Cast<CheckBox>().CurrentValue;
            }

            public static int Slider(Menu m, string s)
            {
                return m[s].Cast<Slider>().CurrentValue;
            }

            public static bool Keybind(Menu m, string s)
            {
                return m[s].Cast<KeyBind>().CurrentValue;
            }

            public static int ComboBox(Menu m, string s)
            {
                return m[s].Cast<ComboBox>().SelectedIndex;
            }
        }
    }
